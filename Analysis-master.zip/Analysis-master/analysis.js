var esprima = require("esprima");
var options = {tokens:true, tolerant: true, loc: true, range: true };
var fs = require("fs");
var istanbul = require('istanbul');
var CyclomaticComplexity = 0;

function main()
{
	var args = process.argv.slice(2);

	if( args.length == 0 )
	{
		args = ["analysis.js"];
	}
	var filePath = args[0];

	complexity(filePath);
	complexityBuilder.report();

	//dynamic(filePath);

}

function dynamic(filePath)
{
	var inst = new istanbul.Instrumenter({embedSource:true});
	var buf = fs.readFileSync(filePath, 'utf8');
	inst.instrument(buf, function (err, data) {
		console.log(data);
	});
}

var complexityBuilder =
{
	Functions:0,

	// Number of if statements/loops + 1
	SimpleCyclomaticComplexity: 0,

	// The max depth of scopes (nested ifs, loops, etc)
	MaxNestingDepth: 0,

	// Average number of parameters for functions-- done !!
	MeanParameterCount: 0,

	// Max number of parameters for functions-- done !!
	MaxParameterCount: 0,

	//calculate function call CallFunction: 0,

	report : function()
	{
		console.log("\nSummarized results are as follows -");
		console.log(
		   ("Number of functions {0}\n" +
			"Cyclomatic complexity {1}\n" +
			"Nesting Depth {2}\n" +
			"Mean Parameters {3}\n" +
			"Max Parameters {4}\n")
			.format(complexityBuilder.Functions,complexityBuilder.SimpleCyclomaticComplexity, this.MaxNestingDepth,
			        complexityBuilder.MeanParameterCount, complexityBuilder.MaxParameterCount)
		);
	}
};

function complexity(filePath)
{
	var buf = fs.readFileSync(filePath, "utf8");
	var result0 = esprima.parse(buf, options);
	var mean=0;
	var temp=0;

	traverse(result0, function (node)
	{

		var result1 = {depth1:0};
		if (node.type === 'FunctionDeclaration')

		{
			var result = {nestedDepth:0};
			visitDepth(node,0,result);

			CallSizeFunction(node,0,result1);


			    console.log( "Line : {0}, Function: {1}, Parameters: {2}, Depth: {3}, FunctionCount: {4}".format(node.loc.start.line,
				functionName(node),node.params.length,result.nestedDepth,result1.depth1));

				temp = node.params.length; //store value in temporary variable

				mean = mean + temp; //add the total to find mean

				//find the maximum parameter count
				if(temp > complexityBuilder.MaxParameterCount)
				{
					complexityBuilder.MaxParameterCount = temp;
				}

				complexityBuilder.Functions++;


				if(result.nestedDepth > complexityBuilder.MaxNestingDepth)
				{
					complexityBuilder.MaxNestingDepth = result.nestedDepth;
				}

		}
				if(isDecision(node)) //to find the line of a function and print the simple cyclomatic complexity
				{
				console.log( "Line : {0} \t Simple Cyclomatic Complexity: {1}".format(node.loc.start.line,node.type));

					complexityBuilder.SimpleCyclomaticComplexity++;
			    }






			complexityBuilder.MeanParameterCount = mean/complexityBuilder.Functions;

	});

}

function traverse(object, visitor)
{
    var key, child;

    visitor.call(null, object);
    for (key in object) {
        if (object.hasOwnProperty(key)) {
            child = object[key];
            if (typeof child === 'object' && child !== null) {
                traverse(child, visitor);
            }
        }
    }
}

//function isDecision

function isDecision(node)
{
	if(node.type == 'IfStatement' || node.type == 'ForStatement' ||
	node.type == 'WhileStatement' || node.type == 'ForInStatement' ||
	node.type == 'DoWhileStatement'|| node.type === 'DoStatement')
		{
			return true;
		}
		return false;

}


function traverseWithCancel(object, visitor)
{
    var key, child;

    if( visitor.call(null, object) )
    {
	    for (key in object) {
	        if (object.hasOwnProperty(key)) {
	            child = object[key];
	            if (typeof child === 'object' && child !== null) {
	                traverseWithCancel(child, visitor);
	            }
	        }
	    }
 	 }
}



function CallSizeFunction (node,depth1,result)
{
	var key,child;

		    for (key in node) {
		       if (node.hasOwnProperty(key)) {
	            child = node[key];
	            if (typeof child === 'object' && child !== null)
				{
					if(child.type==='CallExpression')
					{
						result.depth1++; //when we get a function call increment the result
						CallSizeFunction(child,depth1,result);
						//console.log(depth1); print the number of function calls to check
					}
					else
						CallSizeFunction(child,depth1,result); //if no function call then move ahead
				}
			}
		}




}


function visitDepth(node, depth, result)
{
    var key, child;
	var children = 0;

	    for (key in node)
	    {
	        if (node.hasOwnProperty(key))
	        {
	            child = node[key];
	            if (typeof child === 'object' && child !== null)
	            {
					//console.log(depth);

					if( key == "alternate")
					{
						visitDepth(child, depth, result);
					}
					else if(isDecision(child))
					{
						visitDepth(child,depth+1,result);
					}
					else
					{
						visitDepth(child,depth,result);
					}

	                children++;
	            }
	        }

	    }
	if(children == 0)
	{
		if(result.nestedDepth < depth )
		{
 	 		result.nestedDepth = depth;
			//this.MaxNestingDepth = result.nestedDepth;

		}
	}
}


function functionName( node )
{
	if( node.id )
	{
		return node.id.name;
	}
	return "";
}


if (!String.prototype.format) {
  String.prototype.format = function() {
    var args = arguments;
    return this.replace(/{(\d+)}/g, function(match, number) {
      return typeof args[number] != 'undefined'
        ? args[number]
        : match
      ;
    });
  };
}

main();
